--#--
--Fx info--
--#--
fx_version "cerulean"
use_fxv2_oal "yes"
lua54 "yes"
game "gta5"
version "1.0.1"

--#--
--Resource info--
--#--
name "e_billing"
author "LSE Network"
description "Sistema de facturas de LSE Network Store"

--#--
--Manifest--
--#--
client_scripts {
    "client/*.lua",
    "client/functions/*.lua"
}
server_scripts {
    "server/*.lua",
}

shared_scripts {
    "@ox_lib/init.lua",
    "config.lua"
}
