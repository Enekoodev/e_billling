Config = {}

Config.CommandName = "createbill" 
Config.ItemName = "factura"       
Config.RemoveItem = true         
Config.MetadataOnItem = true     
Config.UseDiscordLogs = true
Config.CanDropItem = false        
Config.CreateBillWebhook = "WEBHOOK"
Config.PayBillWebhook = "WEBHOOK"

Config.AllowedJobs = {
    "mechanic",
    "police",
    "ambulance",
    "prueba"
}

Config.UseForcePay = true

Config.FocePayJobs = {
    "police",
    "ambulance"
}




Config.Lang = {
    mreason      = ">> Razon",
    msociety     = ">> Sociedad",
    mfrom        = ">> De",
    mamount      = ">> Cantidad",
    mdate        = ">> Creado el",
    mstatus      = ">> Estado",
    mPaidDate    = ">> Pagado el",

    billingTitle = "Crear factura",
    reason       = "Razon",
    amount       = "Cantidad",
    sign         = "Sign",

    confermBill  = "Confirma detalles",
    creatingBill = "Creando factura",
    billCreated  = "Factura creada por $",
    billCanceled = "[Error] Creacion de factura abortada",
    noSign       = "[Error] Porfavor pon una Sign",
    noReason     = "[Error] Porfavor, pon una razon valida",
    noAmount     = "[Error] Porfavor, pon una cantidad valida",
    noPlayer     = "[Error] No hay jugadores cerca",

    noMoney      = "[Error] Tu no tienes dinero",
    xnoMoney     = "El cliente no tiene dinero suficiente",
    billPaid     = "La factura fue pagada por $",

    notPaid      = "No pagada",
    bill         = "Factura",

    createdFrom  = "Creado por: ",
    fSociety     = "  \n  Sociedad: ",
    fAmount      = "  \n Cantidad: $",
    fReason      = "  \n  Razon: ",
    fDate        = "  \n  *De:* ",


    checkingDetails = "Checkeando detalles",
    paymentMethod   = "Metodo de pago",
    selectMethod    = "Seleccionar metodo",
    payCash         = "Pagar con efectivo",
    payBank         = "Pagar por banco",
    noMethod        = "Porfavor selecione un metodo de pago",
    conferPayment   = "Confirmar el pago de $",
    wrong           = "Algo esta mal!?",
    paid            = "Pagar",
    alreadyPaid     = "Ya has pagado la factura,
}
